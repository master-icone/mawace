<?php

/* PrevisionnelBundle:Default:autocomplete-cours.html.twig */
class __TwigTemplate_57f85a5b31fd6199044b66b697755c0b9ef15feff25da3ccc200b454f236d1d8 extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = false;

        $this->blocks = array(
        );
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_228f1b4c46e5a7bfb151a11bb5946b38550c4070168425563f70065124b9a20e = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_228f1b4c46e5a7bfb151a11bb5946b38550c4070168425563f70065124b9a20e->enter($__internal_228f1b4c46e5a7bfb151a11bb5946b38550c4070168425563f70065124b9a20e_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "PrevisionnelBundle:Default:autocomplete-cours.html.twig"));

        // line 1
        echo "[";
        $context['_parent'] = $context;
        $context['_seq'] = twig_ensure_traversable((isset($context["results"]) ? $context["results"] : $this->getContext($context, "results")));
        $context['loop'] = array(
          'parent' => $context['_parent'],
          'index0' => 0,
          'index'  => 1,
          'first'  => true,
        );
        if (is_array($context['_seq']) || (is_object($context['_seq']) && $context['_seq'] instanceof Countable)) {
            $length = count($context['_seq']);
            $context['loop']['revindex0'] = $length - 1;
            $context['loop']['revindex'] = $length;
            $context['loop']['length'] = $length;
            $context['loop']['last'] = 1 === $length;
        }
        foreach ($context['_seq'] as $context["_key"] => $context["cours"]) {
            // line 2
            echo twig_jsonencode_filter(array("id" => $this->getAttribute($context["cours"], "id", array()), "label" => $this->getAttribute($context["cours"], "nom", array()), "value" => $this->getAttribute($context["cours"], "nom", array())));
            // line 3
            if ( !$this->getAttribute($context["loop"], "last", array())) {
                echo ",";
            }
            ++$context['loop']['index0'];
            ++$context['loop']['index'];
            $context['loop']['first'] = false;
            if (isset($context['loop']['length'])) {
                --$context['loop']['revindex0'];
                --$context['loop']['revindex'];
                $context['loop']['last'] = 0 === $context['loop']['revindex0'];
            }
        }
        $_parent = $context['_parent'];
        unset($context['_seq'], $context['_iterated'], $context['_key'], $context['cours'], $context['_parent'], $context['loop']);
        $context = array_intersect_key($context, $_parent) + $_parent;
        // line 4
        echo "]";
        
        $__internal_228f1b4c46e5a7bfb151a11bb5946b38550c4070168425563f70065124b9a20e->leave($__internal_228f1b4c46e5a7bfb151a11bb5946b38550c4070168425563f70065124b9a20e_prof);

    }

    public function getTemplateName()
    {
        return "PrevisionnelBundle:Default:autocomplete-cours.html.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  58 => 4,  42 => 3,  40 => 2,  22 => 1,);
    }

    /** @deprecated since 1.27 (to be removed in 2.0). Use getSourceContext() instead */
    public function getSource()
    {
        @trigger_error('The '.__METHOD__.' method is deprecated since version 1.27 and will be removed in 2.0. Use getSourceContext() instead.', E_USER_DEPRECATED);

        return $this->getSourceContext()->getCode();
    }

    public function getSourceContext()
    {
        return new Twig_Source("[{% for cours in results -%}
{{ {id: cours.id, label: cours.nom, value: cours.nom}|json_encode|raw }}
{%- if not loop.last %},{% endif -%}
{%- endfor %}]", "PrevisionnelBundle:Default:autocomplete-cours.html.twig", "E:\\wamp64\\www\\symfony\\src\\Previsionnel\\PrevisionnelBundle/Resources/views/Default/autocomplete-cours.html.twig");
    }
}
