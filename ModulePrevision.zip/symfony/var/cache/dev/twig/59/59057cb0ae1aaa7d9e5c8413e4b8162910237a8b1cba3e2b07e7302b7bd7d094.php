<?php

/* PrevisionnelBundle:Default:index.html.twig */
class __TwigTemplate_b356b1e5c9827c971caf4e3de5055a325d30a36b408b8f83ea132efd78502c38 extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = false;

        $this->blocks = array(
            'stylesheets' => array($this, 'block_stylesheets'),
            'javascripts' => array($this, 'block_javascripts'),
        );
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_3e3fa2032ac13ef7d2cb0f25c127ea2ad6c64e1f2be11ca8bd2c12f7ad0ed3c6 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_3e3fa2032ac13ef7d2cb0f25c127ea2ad6c64e1f2be11ca8bd2c12f7ad0ed3c6->enter($__internal_3e3fa2032ac13ef7d2cb0f25c127ea2ad6c64e1f2be11ca8bd2c12f7ad0ed3c6_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "PrevisionnelBundle:Default:index.html.twig"));

        // line 1
        $this->displayBlock('stylesheets', $context, $blocks);
        // line 5
        echo "
<h1>Module de prévision</h1>

<section>

\t";
        // line 10
        echo         $this->env->getExtension('Symfony\Bridge\Twig\Extension\FormExtension')->renderer->renderBlock((isset($context["form"]) ? $context["form"] : $this->getContext($context, "form")), 'form_start');
        echo "
\t";
        // line 11
        echo $this->env->getExtension('Symfony\Bridge\Twig\Extension\FormExtension')->renderer->searchAndRenderBlock((isset($context["form"]) ? $context["form"] : $this->getContext($context, "form")), 'widget');
        echo "
\t";
        // line 12
        echo         $this->env->getExtension('Symfony\Bridge\Twig\Extension\FormExtension')->renderer->renderBlock((isset($context["form"]) ? $context["form"] : $this->getContext($context, "form")), 'form_end');
        echo "

</section>

";
        // line 16
        $this->displayBlock('javascripts', $context, $blocks);
        
        $__internal_3e3fa2032ac13ef7d2cb0f25c127ea2ad6c64e1f2be11ca8bd2c12f7ad0ed3c6->leave($__internal_3e3fa2032ac13ef7d2cb0f25c127ea2ad6c64e1f2be11ca8bd2c12f7ad0ed3c6_prof);

    }

    // line 1
    public function block_stylesheets($context, array $blocks = array())
    {
        $__internal_9a8138304f39f1a29e12df65eacdf607255813e7171d4bee79d5f84804a2d3dd = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_9a8138304f39f1a29e12df65eacdf607255813e7171d4bee79d5f84804a2d3dd->enter($__internal_9a8138304f39f1a29e12df65eacdf607255813e7171d4bee79d5f84804a2d3dd_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "PrevisionnelBundle:Default:index.html.twig"));

        // line 2
        echo "<link href=\"https://code.jquery.com/ui/1.12.1/themes/base/jquery-ui.css\" rel=\"stylesheet\">
<link href=\"";
        // line 3
        echo twig_escape_filter($this->env, $this->env->getExtension('Symfony\Bridge\Twig\Extension\AssetExtension')->getAssetUrl("css/style.css"), "html", null, true);
        echo "\" rel=\"stylesheet\">
";
        
        $__internal_9a8138304f39f1a29e12df65eacdf607255813e7171d4bee79d5f84804a2d3dd->leave($__internal_9a8138304f39f1a29e12df65eacdf607255813e7171d4bee79d5f84804a2d3dd_prof);

    }

    // line 16
    public function block_javascripts($context, array $blocks = array())
    {
        $__internal_253dc7ae831508a05cf0870efd2a0da5b6e637391572c10dd19002b03eabd99d = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_253dc7ae831508a05cf0870efd2a0da5b6e637391572c10dd19002b03eabd99d->enter($__internal_253dc7ae831508a05cf0870efd2a0da5b6e637391572c10dd19002b03eabd99d_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "PrevisionnelBundle:Default:index.html.twig"));

        // line 17
        echo "<script src=\"https://code.jquery.com/jquery-3.1.1.min.js\"></script>
<script src=\"https://code.jquery.com/ui/1.12.1/jquery-ui.min.js\"></script>
<script src=\"";
        // line 19
        echo twig_escape_filter($this->env, $this->env->getExtension('Symfony\Bridge\Twig\Extension\AssetExtension')->getAssetUrl("bundles/pugxautocompleter/js/autocompleter-jqueryui.js"), "html", null, true);
        echo "\"></script>
<script type=\"text/javascript\">

\t\$('#prevision_idutilisateur').autocompleter({
\t\turl_list: '/symfony/web/app_dev.php/search-utilisateurs',
\t\turl_get: '/symfony/web/app_dev.php/get-utilisateurs/'
\t});
\t
\t\$('#prevision_ue').autocompleter({
\t\turl_list: '/symfony/web/app_dev.php/search-ue',
\t\turl_get: '/symfony/web/app_dev.php/get-ue/'
\t});
\t
\t\$('#prevision_typecours').autocompleter({
\t\turl_list: '/symfony/web/app_dev.php/search-typecours',
\t\turl_get: '/symfony/web/app_dev.php/get-typecours/'
\t});

</script>
";
        
        $__internal_253dc7ae831508a05cf0870efd2a0da5b6e637391572c10dd19002b03eabd99d->leave($__internal_253dc7ae831508a05cf0870efd2a0da5b6e637391572c10dd19002b03eabd99d_prof);

    }

    public function getTemplateName()
    {
        return "PrevisionnelBundle:Default:index.html.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  83 => 19,  79 => 17,  73 => 16,  64 => 3,  61 => 2,  55 => 1,  48 => 16,  41 => 12,  37 => 11,  33 => 10,  26 => 5,  24 => 1,);
    }

    /** @deprecated since 1.27 (to be removed in 2.0). Use getSourceContext() instead */
    public function getSource()
    {
        @trigger_error('The '.__METHOD__.' method is deprecated since version 1.27 and will be removed in 2.0. Use getSourceContext() instead.', E_USER_DEPRECATED);

        return $this->getSourceContext()->getCode();
    }

    public function getSourceContext()
    {
        return new Twig_Source("{% block stylesheets %}
<link href=\"https://code.jquery.com/ui/1.12.1/themes/base/jquery-ui.css\" rel=\"stylesheet\">
<link href=\"{{ asset('css/style.css') }}\" rel=\"stylesheet\">
{% endblock %}

<h1>Module de prévision</h1>

<section>

\t{{ form_start(form) }}
\t{{ form_widget(form) }}
\t{{ form_end(form) }}

</section>

{% block javascripts %}
<script src=\"https://code.jquery.com/jquery-3.1.1.min.js\"></script>
<script src=\"https://code.jquery.com/ui/1.12.1/jquery-ui.min.js\"></script>
<script src=\"{{ asset('bundles/pugxautocompleter/js/autocompleter-jqueryui.js') }}\"></script>
<script type=\"text/javascript\">

\t\$('#prevision_idutilisateur').autocompleter({
\t\turl_list: '/symfony/web/app_dev.php/search-utilisateurs',
\t\turl_get: '/symfony/web/app_dev.php/get-utilisateurs/'
\t});
\t
\t\$('#prevision_ue').autocompleter({
\t\turl_list: '/symfony/web/app_dev.php/search-ue',
\t\turl_get: '/symfony/web/app_dev.php/get-ue/'
\t});
\t
\t\$('#prevision_typecours').autocompleter({
\t\turl_list: '/symfony/web/app_dev.php/search-typecours',
\t\turl_get: '/symfony/web/app_dev.php/get-typecours/'
\t});

</script>
{% endblock %}", "PrevisionnelBundle:Default:index.html.twig", "C:\\wamp64\\www\\symfony\\src\\Previsionnel\\PrevisionnelBundle/Resources/views/Default/index.html.twig");
    }
}
