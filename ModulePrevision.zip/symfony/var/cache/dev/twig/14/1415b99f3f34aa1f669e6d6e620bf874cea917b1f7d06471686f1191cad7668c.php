<?php

/* PrevisionnelBundle:Default:results.html.twig */
class __TwigTemplate_5ed310ec4c17a3ec522d66e5db99c9ff1e4c780af72d6a76a31f57e339f5fda1 extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = false;

        $this->blocks = array(
        );
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_ba6c40e5a806fd6f787d9259b7e1260338a8ceb55f6711216077a8ef601e97dd = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_ba6c40e5a806fd6f787d9259b7e1260338a8ceb55f6711216077a8ef601e97dd->enter($__internal_ba6c40e5a806fd6f787d9259b7e1260338a8ceb55f6711216077a8ef601e97dd_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "PrevisionnelBundle:Default:results.html.twig"));

        // line 1
        echo "[";
        $context['_parent'] = $context;
        $context['_seq'] = twig_ensure_traversable((isset($context["results"]) ? $context["results"] : $this->getContext($context, "results")));
        $context['loop'] = array(
          'parent' => $context['_parent'],
          'index0' => 0,
          'index'  => 1,
          'first'  => true,
        );
        if (is_array($context['_seq']) || (is_object($context['_seq']) && $context['_seq'] instanceof Countable)) {
            $length = count($context['_seq']);
            $context['loop']['revindex0'] = $length - 1;
            $context['loop']['revindex'] = $length;
            $context['loop']['length'] = $length;
            $context['loop']['last'] = 1 === $length;
        }
        foreach ($context['_seq'] as $context["_key"] => $context["utilisateur"]) {
            // line 2
            echo twig_jsonencode_filter(array("id" => $this->getAttribute($context["utilisateur"], "id", array()), "label" => (($this->getAttribute($context["utilisateur"], "nom", array()) . " ") . $this->getAttribute($context["utilisateur"], "prenom", array())), "value" => (($this->getAttribute($context["utilisateur"], "nom", array()) . " ") . $this->getAttribute($context["utilisateur"], "prenom", array()))));
            // line 3
            if ( !$this->getAttribute($context["loop"], "last", array())) {
                echo ",";
            }
            ++$context['loop']['index0'];
            ++$context['loop']['index'];
            $context['loop']['first'] = false;
            if (isset($context['loop']['length'])) {
                --$context['loop']['revindex0'];
                --$context['loop']['revindex'];
                $context['loop']['last'] = 0 === $context['loop']['revindex0'];
            }
        }
        $_parent = $context['_parent'];
        unset($context['_seq'], $context['_iterated'], $context['_key'], $context['utilisateur'], $context['_parent'], $context['loop']);
        $context = array_intersect_key($context, $_parent) + $_parent;
        // line 4
        echo "]";
        
        $__internal_ba6c40e5a806fd6f787d9259b7e1260338a8ceb55f6711216077a8ef601e97dd->leave($__internal_ba6c40e5a806fd6f787d9259b7e1260338a8ceb55f6711216077a8ef601e97dd_prof);

    }

    public function getTemplateName()
    {
        return "PrevisionnelBundle:Default:results.html.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  58 => 4,  42 => 3,  40 => 2,  22 => 1,);
    }

    /** @deprecated since 1.27 (to be removed in 2.0). Use getSourceContext() instead */
    public function getSource()
    {
        @trigger_error('The '.__METHOD__.' method is deprecated since version 1.27 and will be removed in 2.0. Use getSourceContext() instead.', E_USER_DEPRECATED);

        return $this->getSourceContext()->getCode();
    }

    public function getSourceContext()
    {
        return new Twig_Source("[{% for utilisateur in results -%}
{{ {id: utilisateur.id, label: utilisateur.nom ~ \" \" ~ utilisateur.prenom, value: utilisateur.nom ~ \" \" ~ utilisateur.prenom}|json_encode|raw }}
{%- if not loop.last %},{% endif -%}
{%- endfor %}]", "PrevisionnelBundle:Default:results.html.twig", "E:\\wamp64\\www\\symfony\\src\\Previsionnel\\PrevisionnelBundle/Resources/views/Default/results.html.twig");
    }
}
