<?php

/* PrevisionnelBundle:Default:index.html.twig */
class __TwigTemplate_95c5af8139c4cef07ca2d6b1a94593aefcd88ee44bcab5eac4ebb6cc9e972987 extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = false;

        $this->blocks = array(
            'stylesheets' => array($this, 'block_stylesheets'),
            'javascripts' => array($this, 'block_javascripts'),
        );
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_934d8846bc8096c0d936999f5e97e85386e4a7d5a25d6be25635bbf810b6bf7b = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_934d8846bc8096c0d936999f5e97e85386e4a7d5a25d6be25635bbf810b6bf7b->enter($__internal_934d8846bc8096c0d936999f5e97e85386e4a7d5a25d6be25635bbf810b6bf7b_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "PrevisionnelBundle:Default:index.html.twig"));

        // line 1
        $this->displayBlock('stylesheets', $context, $blocks);
        // line 5
        echo "
<h1>Module de prévision</h1>

<section>

\t";
        // line 10
        echo         $this->env->getExtension('Symfony\Bridge\Twig\Extension\FormExtension')->renderer->renderBlock((isset($context["form"]) ? $context["form"] : $this->getContext($context, "form")), 'form_start');
        echo "
\t";
        // line 11
        echo $this->env->getExtension('Symfony\Bridge\Twig\Extension\FormExtension')->renderer->searchAndRenderBlock((isset($context["form"]) ? $context["form"] : $this->getContext($context, "form")), 'widget');
        echo "
\t";
        // line 12
        echo         $this->env->getExtension('Symfony\Bridge\Twig\Extension\FormExtension')->renderer->renderBlock((isset($context["form"]) ? $context["form"] : $this->getContext($context, "form")), 'form_end');
        echo "

</section>

";
        // line 16
        $this->displayBlock('javascripts', $context, $blocks);
        
        $__internal_934d8846bc8096c0d936999f5e97e85386e4a7d5a25d6be25635bbf810b6bf7b->leave($__internal_934d8846bc8096c0d936999f5e97e85386e4a7d5a25d6be25635bbf810b6bf7b_prof);

    }

    // line 1
    public function block_stylesheets($context, array $blocks = array())
    {
        $__internal_26574220b9258a0ebefb9a24e63b6318a40f729f1f818d0cc6f77de04d1c45e3 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_26574220b9258a0ebefb9a24e63b6318a40f729f1f818d0cc6f77de04d1c45e3->enter($__internal_26574220b9258a0ebefb9a24e63b6318a40f729f1f818d0cc6f77de04d1c45e3_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "PrevisionnelBundle:Default:index.html.twig"));

        // line 2
        echo "<link href=\"https://code.jquery.com/ui/1.12.1/themes/base/jquery-ui.css\" rel=\"stylesheet\">
<link href=\"";
        // line 3
        echo twig_escape_filter($this->env, $this->env->getExtension('Symfony\Bridge\Twig\Extension\AssetExtension')->getAssetUrl("css/style.css"), "html", null, true);
        echo "\" rel=\"stylesheet\">
";
        
        $__internal_26574220b9258a0ebefb9a24e63b6318a40f729f1f818d0cc6f77de04d1c45e3->leave($__internal_26574220b9258a0ebefb9a24e63b6318a40f729f1f818d0cc6f77de04d1c45e3_prof);

    }

    // line 16
    public function block_javascripts($context, array $blocks = array())
    {
        $__internal_064ab14d5971bcca7641bbedb9ad9b6cec4f6e146e4227df404b2c89cbbc852c = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_064ab14d5971bcca7641bbedb9ad9b6cec4f6e146e4227df404b2c89cbbc852c->enter($__internal_064ab14d5971bcca7641bbedb9ad9b6cec4f6e146e4227df404b2c89cbbc852c_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "PrevisionnelBundle:Default:index.html.twig"));

        // line 17
        echo "<script src=\"https://code.jquery.com/jquery-3.1.1.min.js\"></script>
<script src=\"https://code.jquery.com/ui/1.12.1/jquery-ui.min.js\"></script>
<script src=\"";
        // line 19
        echo twig_escape_filter($this->env, $this->env->getExtension('Symfony\Bridge\Twig\Extension\AssetExtension')->getAssetUrl("bundles/pugxautocompleter/js/autocompleter-jqueryui.js"), "html", null, true);
        echo "\"></script>
<script type=\"text/javascript\">

\t\$('#prevision_idutilisateur').autocompleter({
\t\turl_list: '/symfony/web/app_dev.php/search-utilisateurs',
\t\turl_get: '/symfony/web/app_dev.php/get-utilisateurs/'
\t});
\t
\t\$('#prevision_ue').autocompleter({
\t\turl_list: '/symfony/web/app_dev.php/search-ue',
\t\turl_get: '/symfony/web/app_dev.php/get-ue/'
\t});
\t
\t\$('#prevision_typecours').autocompleter({
\t\turl_list: '/symfony/web/app_dev.php/search-typecours',
\t\turl_get: '/symfony/web/app_dev.php/get-typecours/'
\t});

</script>
";
        
        $__internal_064ab14d5971bcca7641bbedb9ad9b6cec4f6e146e4227df404b2c89cbbc852c->leave($__internal_064ab14d5971bcca7641bbedb9ad9b6cec4f6e146e4227df404b2c89cbbc852c_prof);

    }

    public function getTemplateName()
    {
        return "PrevisionnelBundle:Default:index.html.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  83 => 19,  79 => 17,  73 => 16,  64 => 3,  61 => 2,  55 => 1,  48 => 16,  41 => 12,  37 => 11,  33 => 10,  26 => 5,  24 => 1,);
    }

    /** @deprecated since 1.27 (to be removed in 2.0). Use getSourceContext() instead */
    public function getSource()
    {
        @trigger_error('The '.__METHOD__.' method is deprecated since version 1.27 and will be removed in 2.0. Use getSourceContext() instead.', E_USER_DEPRECATED);

        return $this->getSourceContext()->getCode();
    }

    public function getSourceContext()
    {
        return new Twig_Source("{% block stylesheets %}
<link href=\"https://code.jquery.com/ui/1.12.1/themes/base/jquery-ui.css\" rel=\"stylesheet\">
<link href=\"{{ asset('css/style.css') }}\" rel=\"stylesheet\">
{% endblock %}

<h1>Module de prévision</h1>

<section>

\t{{ form_start(form) }}
\t{{ form_widget(form) }}
\t{{ form_end(form) }}

</section>

{% block javascripts %}
<script src=\"https://code.jquery.com/jquery-3.1.1.min.js\"></script>
<script src=\"https://code.jquery.com/ui/1.12.1/jquery-ui.min.js\"></script>
<script src=\"{{ asset('bundles/pugxautocompleter/js/autocompleter-jqueryui.js') }}\"></script>
<script type=\"text/javascript\">

\t\$('#prevision_idutilisateur').autocompleter({
\t\turl_list: '/symfony/web/app_dev.php/search-utilisateurs',
\t\turl_get: '/symfony/web/app_dev.php/get-utilisateurs/'
\t});
\t
\t\$('#prevision_ue').autocompleter({
\t\turl_list: '/symfony/web/app_dev.php/search-ue',
\t\turl_get: '/symfony/web/app_dev.php/get-ue/'
\t});
\t
\t\$('#prevision_typecours').autocompleter({
\t\turl_list: '/symfony/web/app_dev.php/search-typecours',
\t\turl_get: '/symfony/web/app_dev.php/get-typecours/'
\t});

</script>
{% endblock %}", "PrevisionnelBundle:Default:index.html.twig", "E:\\wamp64\\www\\symfony\\src\\Previsionnel\\PrevisionnelBundle/Resources/views/Default/index.html.twig");
    }
}
