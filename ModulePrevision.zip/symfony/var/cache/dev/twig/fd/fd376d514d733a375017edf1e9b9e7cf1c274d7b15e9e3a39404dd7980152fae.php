<?php

/* @WebProfiler/Collector/router.html.twig */
class __TwigTemplate_9d25a082ae1325497a61a8becc7d0075d16e3b0f9ba424e30d76b44e987a3c1d extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        // line 1
        $this->parent = $this->loadTemplate("@WebProfiler/Profiler/layout.html.twig", "@WebProfiler/Collector/router.html.twig", 1);
        $this->blocks = array(
            'toolbar' => array($this, 'block_toolbar'),
            'menu' => array($this, 'block_menu'),
            'panel' => array($this, 'block_panel'),
        );
    }

    protected function doGetParent(array $context)
    {
        return "@WebProfiler/Profiler/layout.html.twig";
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_afdb4f4eee89a83637f3f6411c66d67d61c0d6443191248e697273697ef77da9 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_afdb4f4eee89a83637f3f6411c66d67d61c0d6443191248e697273697ef77da9->enter($__internal_afdb4f4eee89a83637f3f6411c66d67d61c0d6443191248e697273697ef77da9_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "@WebProfiler/Collector/router.html.twig"));

        $this->parent->display($context, array_merge($this->blocks, $blocks));
        
        $__internal_afdb4f4eee89a83637f3f6411c66d67d61c0d6443191248e697273697ef77da9->leave($__internal_afdb4f4eee89a83637f3f6411c66d67d61c0d6443191248e697273697ef77da9_prof);

    }

    // line 3
    public function block_toolbar($context, array $blocks = array())
    {
        $__internal_9fe7ccbf0e2e9e919fb687691acdd633e4886dbad6508809abb3beb0e7ac9b09 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_9fe7ccbf0e2e9e919fb687691acdd633e4886dbad6508809abb3beb0e7ac9b09->enter($__internal_9fe7ccbf0e2e9e919fb687691acdd633e4886dbad6508809abb3beb0e7ac9b09_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "@WebProfiler/Collector/router.html.twig"));

        
        $__internal_9fe7ccbf0e2e9e919fb687691acdd633e4886dbad6508809abb3beb0e7ac9b09->leave($__internal_9fe7ccbf0e2e9e919fb687691acdd633e4886dbad6508809abb3beb0e7ac9b09_prof);

    }

    // line 5
    public function block_menu($context, array $blocks = array())
    {
        $__internal_fc805bf491704d4ae8de3981a0b7444f38f91c917c49952c0695fd5fc35ebca1 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_fc805bf491704d4ae8de3981a0b7444f38f91c917c49952c0695fd5fc35ebca1->enter($__internal_fc805bf491704d4ae8de3981a0b7444f38f91c917c49952c0695fd5fc35ebca1_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "@WebProfiler/Collector/router.html.twig"));

        // line 6
        echo "<span class=\"label\">
    <span class=\"icon\">";
        // line 7
        echo twig_include($this->env, $context, "@WebProfiler/Icon/router.svg");
        echo "</span>
    <strong>Routing</strong>
</span>
";
        
        $__internal_fc805bf491704d4ae8de3981a0b7444f38f91c917c49952c0695fd5fc35ebca1->leave($__internal_fc805bf491704d4ae8de3981a0b7444f38f91c917c49952c0695fd5fc35ebca1_prof);

    }

    // line 12
    public function block_panel($context, array $blocks = array())
    {
        $__internal_32f9c3ae544d76a3db20f0e09e1b84777567dbee5f7fe17e4d17338af452b265 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_32f9c3ae544d76a3db20f0e09e1b84777567dbee5f7fe17e4d17338af452b265->enter($__internal_32f9c3ae544d76a3db20f0e09e1b84777567dbee5f7fe17e4d17338af452b265_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "@WebProfiler/Collector/router.html.twig"));

        // line 13
        echo "    ";
        echo $this->env->getExtension('Symfony\Bridge\Twig\Extension\HttpKernelExtension')->renderFragment($this->env->getExtension('Symfony\Bridge\Twig\Extension\RoutingExtension')->getPath("_profiler_router", array("token" => (isset($context["token"]) ? $context["token"] : $this->getContext($context, "token")))));
        echo "
";
        
        $__internal_32f9c3ae544d76a3db20f0e09e1b84777567dbee5f7fe17e4d17338af452b265->leave($__internal_32f9c3ae544d76a3db20f0e09e1b84777567dbee5f7fe17e4d17338af452b265_prof);

    }

    public function getTemplateName()
    {
        return "@WebProfiler/Collector/router.html.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  73 => 13,  67 => 12,  56 => 7,  53 => 6,  47 => 5,  36 => 3,  11 => 1,);
    }

    /** @deprecated since 1.27 (to be removed in 2.0). Use getSourceContext() instead */
    public function getSource()
    {
        @trigger_error('The '.__METHOD__.' method is deprecated since version 1.27 and will be removed in 2.0. Use getSourceContext() instead.', E_USER_DEPRECATED);

        return $this->getSourceContext()->getCode();
    }

    public function getSourceContext()
    {
        return new Twig_Source("{% extends '@WebProfiler/Profiler/layout.html.twig' %}

{% block toolbar %}{% endblock %}

{% block menu %}
<span class=\"label\">
    <span class=\"icon\">{{ include('@WebProfiler/Icon/router.svg') }}</span>
    <strong>Routing</strong>
</span>
{% endblock %}

{% block panel %}
    {{ render(path('_profiler_router', { token: token })) }}
{% endblock %}
", "@WebProfiler/Collector/router.html.twig", "C:\\wamp64\\www\\symfony\\vendor\\symfony\\symfony\\src\\Symfony\\Bundle\\WebProfilerBundle\\Resources\\views\\Collector\\router.html.twig");
    }
}
