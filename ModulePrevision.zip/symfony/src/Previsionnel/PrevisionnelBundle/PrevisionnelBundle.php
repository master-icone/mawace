<?php

namespace Previsionnel\PrevisionnelBundle;

use Symfony\Component\HttpKernel\Bundle\Bundle;

class PrevisionnelBundle extends Bundle
{
}
